"use strict";

module.exports = require("./is-implemented")() ? Math.expm1 : require("./shim");
